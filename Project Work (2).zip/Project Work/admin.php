<!DOCTYPE html>
<html>
<head>
  <title>SenSa(QA Platform)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>

  <div class="sign">
    <img src="user-icon.png" width="100px">
    <h1>Admin Sign-Up</h1>
    <form action="adminsignup.php" method="post">
    <div class="form-group">
    <input type="username" name="uname" class="form-control" id="user" aria-describedby="user" placeholder="User Name" required="">
    <br>
    <input type="email" name="email" class="form-control" id="Email1" aria-describedby="email" placeholder="Enter email" required="">
     <br>
     <input type="password" name="password" class="form-control" id="Password1" placeholder="Password" required="">
     <br>
     <input type="password" name="cpassword" class="form-control" id="Password2" placeholder="Confirm Password" required="">
    </div><br>
     <button type="submit" class="btn btn-primary">Submit</button>
     <br><br>
    <p>Do you have an account?<a href="adminlogin.php">Login</a></p>
     </form>
  </div>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>