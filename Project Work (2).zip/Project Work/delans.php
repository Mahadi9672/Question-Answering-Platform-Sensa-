<?php
    session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'sensa');


	$ansid=$_GET['ansid'];
	$query="delete from answer where ansid='$ansid'";
	$data=mysqli_query($con,$query);
	if($data){
	header("Location: mypic.php?info=added");
	exit();
	}
	else{
	echo "<br>";
	echo "<h1><center>Failed to delete</h1></center>";
	}
	?>
