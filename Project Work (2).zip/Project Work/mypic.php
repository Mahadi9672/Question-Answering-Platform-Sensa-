
<?php
    session_start();
    $con=mysqli_connect('localhost:3307','root','');
    mysqli_select_db($con,'sensa');
?>
<?php include 'nav.php';?>
<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Profile Of User</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="fontawesome.min.css" rel="stylesheet">
    <link href="mypic.css" rel="stylesheet">
</head>

<body>
<div class="container bootstrap snippets bootdey">
    <div class="row">

        <!-- BEGIN USER PROFILE -->
        <div class="col-md-12">
            <div class="grid profile">
                <div class="grid-header">
                    <div class="col-xs-2">
                          <?php
                          $session_user_name = $_SESSION['uname'];
                          $qry="select * from user where uname='$session_user_name'";
                          $result=mysqli_query($con,$qry);
                          $row=mysqli_fetch_assoc($result);
                          ?>
                        <img src=" <?php  echo $row['image']; ?>" class="img-circle" alt="logo">
                    </div>
                    <div class="col-xs-7"><br>
                        <h3><?php  echo $row['fname']; ?></h3>
                        <p><?php  echo $row['uname']; ?></p>
                        <p><?php  echo $row['location']; ?></p>
                        <button class="btn btn-success"> Ranking : 
                     <?php
                     $con=mysqli_connect('localhost:3307','root','','sensa');
                      $result = mysqli_query($con, "SELECT user_name,total_question FROM ranking ORDER BY total_question DESC");
                      $ranking = 1;
                        while($row=mysqli_fetch_assoc($result)){
                            if($row['user_name']==$session_user_name){
                                echo $ranking;
                            }
                        
                      $ranking++;
                      }


                    ?>

</button>
          </div>
                </div>

                <div class="grid-body">

                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#profile" data-toggle="tab">Profile</a></li>
                        <li class=""><a href="#timeline" data-toggle="tab">Questions</a></li>
                        <li class=""><a href="#photos" data-toggle="tab">Answers</a></li>
                        <li class=""><a href="#settings" data-toggle="tab">Blog</a></li>
                    </ul>

                    <div class="tab-content">

                        <!-- BEGIN PROFILE -->
                        <div class="tab-pane active" id="profile"><br>
                            <p class="lead">My Profile</p>
                         
                            <div class="row">
                         
                                <div class="col-md-6">
                                  <?php
                                  $session_user_name = $_SESSION['uname'];
                                  
                                  $qry="select * from user where uname='$session_user_name'";
                                  $result=mysqli_query($con,$qry);
                                  $row=mysqli_fetch_assoc($result);
                                  ?>
                            <table class="table table-responsive ml-4">
                                            <tr>
                                                <td class="text-muted">Full Name</td>
                                                <td>:</td>
                                                <td><?php  echo $row['fname']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">User Name</td>
                                                <td>:</td>
                                                <td><?php  echo $row['uname']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Email Address</td>
                                                <td>:</td>
                                                <td><?php  echo $row['email']; ?> </td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Password</td>
                                                <td>:</td>
                                                <td><?php  echo $row['password']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Qualification</td>
                                                <td>:</td>
                                                <td><?php  echo $row['qualification']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Skill</td>
                                                <td>:</td>
                                                <td> <?php  echo $row['skill']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">LOCATION</td>
                                                <td>:</td>
                                                <td><?php  echo $row['location']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Follower</td>
                                                <td>:</td>
                                                <td><?php  echo $row['follower']; ?></td>
                                            </tr>
                                        </table>
                                        <?php echo "<a href='updateprofile.php?email=$row[email]' class='btn btn-dark btn-sm'>Update Profile</a>";?><br>
                                    </div>
                               
                                    </div>

                            <div class="row">
                            <div class="col-sm-4 stats">
                            <br><br>
                            <?php
                            $session_user_name = $_SESSION['uname'];
                            $qry="select * from question where uname='$session_user_name'";
                            $result=mysqli_query($con,$qry);
                            $row=mysqli_num_rows($result);
                            echo '<h1>'.$row.'</h1><br>';
                            echo '<button class="btn btn-primary"></i>Asked Question : ' .$row.'</button>';
                            $row=mysqli_fetch_assoc($result);
                            ?>
                            </div>
                            <div class="col-sm-4 stats">
                            <br><br>
                            <?php
                            $session_user_name = $_SESSION['uname'];
                            $qry="select * from answer where uname='$session_user_name'";
                            $result=mysqli_query($con,$qry);
                            $row=mysqli_num_rows($result);
                            echo '<h1>'.$row.'</h1><br>';
                            echo '<button class="btn btn-success"></i>Solved Answer</button><br>';
                            $row=mysqli_fetch_assoc($result);
                            ?>
                            <br><br>
                            </div>
                            <div class="col-sm-4 stats">
                            <br><br>
                            <?php
                            $session_user_name = $_SESSION['uname'];
                            $qry="select * from blog where uname='$session_user_name'";
                            $result=mysqli_query($con,$qry);
                            $row=mysqli_num_rows($result);
                            echo '<h1>'.$row.'</h1><br>';
                            echo '<button class="btn btn-info"></i>Published Blog</button>';
                            $row=mysqli_fetch_assoc($result);
                            ?>
                            </div>

                        </div>
                               
                       <br><br>
                         

                    </div>

                    <!-- END PROFILE -->
                    
                            
                    <!-- BEGIN QUESTION LIST -->
                    <div class="tab-pane" id="timeline"><br>
                       
                        <div class="row">
                        <div class="col-md-12">
                            <?php
                            $session_user_name = $_SESSION['uname'];
                            $qry="select * from question where uname='$session_user_name'";
                            $result=mysqli_query($con,$qry);
                            $row=mysqli_num_rows($result);
                            echo '<p class="lead"> Total Question : '.$row.'</p><hr>';
                            while($row=mysqli_fetch_assoc($result)){
                            ?>

                          <h4><?php echo $row['details']; ?></h4>
                          

                    <?php echo "<a href='editques.php?quesid=$row[quesid]' class='btn btn-primary btn-sm'>Edit</a>";?>
                    <?php echo "<a href='delques.php?quesid=$row[quesid]' class='btn btn-danger btn-sm'>Delete</a>";?>
                      

                             <?php
                             
                             }

                            ?>
                        </div>
                    </div>
                </div>
                <!-- END QUESTION LIST -->

                <!-- BEGIN SHOW ANSWER -->
                <div class="tab-pane" id="photos"><br>
                    <div class="row">
                        <div class="col-md-12">
                          <?php
                            $session_user_name = $_SESSION['uname'];
                            $qry="select * from answer where uname='$session_user_name'";
                            $result=mysqli_query($con,$qry);
                            $row=mysqli_num_rows($result);
                            echo '<p class="lead"> Total Answer : '.$row.'</p><hr>';
                            while($row=mysqli_fetch_assoc($result)){
                            ?>
                          <h4><?php echo $row['details']; ?></h4>
                        <?php echo "<a href='editans.php?ansid=$row[ansid]' class='btn btn-primary btn-sm'>Edit</a>";?>
                           <?php echo "<a href='delans.php?ansid=$row[ansid]' class='btn btn-primary btn-sm'>Delete</a>";?>
                      

                             <?php

                             }

                            ?>
                        </div>
                    </div>
                </div>
                <!-- END SHOW ANSWER -->

                <!-- BEGIN BLOG -->
                <div class="tab-pane" id="settings"><br>
                    <div class="row">
                        <div class="col-md-12">
                             <?php
                            $session_user_name = $_SESSION['uname'];
                            $qry="select * from blog where uname='$session_user_name'";
                            $result=mysqli_query($con,$qry);
                            $row=mysqli_num_rows($result);
                            echo '<p class="lead"> Total Write Blog : '.$row.'</p><hr>';
                            while($row=mysqli_fetch_assoc($result)){
                            ?>
                          <h4><?php echo $row['details']; ?></h4>
                        <?php echo "<a href='editblog.php?blogid=$row[blogid]' class='btn btn-primary btn-sm'>Edit</a>";?>
                           <?php echo "<a href='delblog.php?blogid=$row[blogid]' class='btn btn-primary btn-sm'>Delete</a>";?>
                      

                             <?php

                             }

                            ?>
                        </div>
                    </div>
                </div>
                <!-- END BLOG -->

                </div>
            </div>
        </div>
    </div>
    <!-- END USER PROFILE -->

</div>
</div>
<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script type="text/javascript">
	
</script>
</body>
</html>

        <?php
          



        ?>