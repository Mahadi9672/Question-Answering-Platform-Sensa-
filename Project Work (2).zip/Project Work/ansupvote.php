<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'sensa');
?>

<?php

if(isset($_POST['type']) && $_POST['type']!='' && isset($_POST['ansid']) 
&& $_POST['ansid']>0){
	$type=mysqli_real_escape_string($con,$_POST['type']);
	$ansid=mysqli_real_escape_string($con,$_POST['ansid']);

		if($type=='upvote'){
			if(isset($_COOKIE['upvote_'.$ansid])){
			   setcookie('upvote_'.$ansid,"yes",1);
			   $sql="UPDATE answer set upvote=upvote-1 where ansid='$ansid'";
			   $operation="unupvote";
			}else{

                if(isset($_COOKIE['downvote_'.$ansid])){
			    setcookie('downvote_'.$ansid,"yes",1);
			    mysqli_query($con,"UPDATE answer set downvote=downvote-1 where ansid='$ansid'");
			   
			   }



				setcookie('upvote_'.$ansid,"yes",time()+60*60*24*365*5);
				$sql="UPDATE answer set upvote=upvote+1 where ansid='$ansid'";
				$operation="upvote";
			}
			
		}

		if($type=='downvote'){
			if(isset($_COOKIE['downvote_'.$ansid])){
			   setcookie('downvote_'.$ansid,"yes",1);
			   $sql="UPDATE answer set downvote=downvote-1 where ansid='$ansid'";
			    $operation="undownvote";
			}else{

                 if(isset($_COOKIE['upvote_'.$ansid])){
			    setcookie('upvote_'.$ansid,"yes",1);
			    mysqli_query($con,"UPDATE answer set upvote=upvote-1 where ansid='$ansid'");
			   
			   }





				setcookie('downvote_'.$ansid,"yes",time()+60*60*24*365*5);
				$sql="UPDATE answer set downvote=downvote+1 where ansid='$ansid'";
				  $operation="downvote";
			}
			
		}
		mysqli_query($con,$sql);
		$row=mysqli_fetch_assoc(mysqli_query($con,"select * from answer where ansid='$ansid'"));

		echo json_encode([
		'operation'=>$operation,
		'upvote'=>$row['upvote'],
		'downvote'=>$row['downvote']

		]);
}

?>