<!DOCTYPE html>
<html>
<head>
	<title>SenSa(QA Platform)</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	
</head>
<body>

	<!---Navigation Part--->

  <section id="navbar-pos">
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<div class="container">
			<a href="Home.php" class="navbar-brand">SenSa(Question Answering Platform)</a>
			<button class="navbar-toggler navbar-toggler-right"></button>


			<div>
				<ul class="navbar-nav">
				
				
				<li class="nav-item">
						<a  class="nav-link" href="notes.php">Tutorial</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="notes.php">Blog</a>
					</li>
					
				    <li class="nav-item">
						<a   class="nav-link" href="question.php">Ask a Question</a>
					</li>

					 <li class="nav-item">
						<a   class="nav-link" href="following.php">Follow</a>
					</li>

				        <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><?php echo $_SESSION['uname'];?></a>
						<div class="dropdown-menu dropdown-menu-dark">

                            <a href="profile.php" class="dropdown-item">Profile</a>
						    <a href="#" class="dropdown-item">Question</a>
						    <a href="#" class="dropdown-item">Answer</a>
						    <a href="#" class="dropdown-item">Following</a>
						    <a href="#" class="dropdown-item">Follower</a>
						    <a href="#" class="dropdown-item">Logout</a>
						</div>
					   </li>
					   
                    </ul>
				</div>
			</div>
		</nav>
</section>
<br>