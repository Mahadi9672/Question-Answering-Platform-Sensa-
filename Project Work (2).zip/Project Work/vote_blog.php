<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','','sensa');
?>

<?php
    $blogid = $_GET['id'];
    echo $blogid;
    $v = $_GET['v'];
    $user=$_SESSION['uname'];
    $data = "SELECT * FROM `vote_blog` WHERE blogid = '$blogid' AND user_id = '$user'";
    $result = mysqli_query($con, $data);
    $row = mysqli_fetch_array($result);
    $ver = mysqli_num_rows($result);

    if ($ver > 0) {
        $del = "DELETE FROM vote_blog WHERE blogid = '$blogid' AND user_id= '$user'";
        $del_f = mysqli_query($con, $del);
        header("location: blog.php");
    }

        if($v != $row['vote']){
            $vote = "INSERT INTO vote_blog (`blogid`, `user_id`, `vote`, `time`) VALUES ('$blogid', '$user', $v, NOW())";
            $vote_f = mysqli_query($con, $vote);
            header("location: blog.php");
        }
    
    
?>