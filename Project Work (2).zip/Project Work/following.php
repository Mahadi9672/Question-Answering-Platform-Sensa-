<?php
  session_start();
  $con=mysqli_connect('localhost:3307','root','','sensa');
?>

<!DOCTYPE html>
<html>
<head>
  <title>SenSa(QA Platform)</title>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="profile.css">
  <link href="css/all.min.css" rel="stylesheet">
  <link href="fontawesome.min.css" rel="stylesheet">


</head>
<body>

  <!---Navigation Part--->
<section id="navbar-pos">
  <nav class="navbar navbar-expand-lg">
    <div class="container">
      <a href="Home.php" class="navbar-brand">SenSa(Question Answering Platform)</a>
      <button class="navbar-toggler navbar-toggler-right"></button>


      <div>
        <ul class="navbar-nav">
        
          <li class="nav-item">
            <a  class="nav-link" href="upage.php">Home</a>
          </li>
          
            
          <li class="nav-item">
            <a  class="nav-link" href="blog.php">Blog</a>
          </li>
          
            <li class="nav-item ">
            <a   class="nav-link" href="question.php">Ask a Question</a>
          </li>

           <li class="nav-item ">
            <a   class="nav-link" href="following.php">Follow</a>
          </li>

          <li class="nav-item">
          <a  class="nav-link" href="answer.php">Answer</a>
          </li>

          <li class="nav-item">
          <a  class="nav-link" href="ranking.php">Ranking</a>
          </li>

            <li class="nav-item">
              <?php
              $session_user_name = $_SESSION['uname'];
              $qry="select * from user where uname='$session_user_name'";
              $result=mysqli_query($con,$qry);
              $row=mysqli_fetch_assoc($result);
              ?>
             <a href="mypic.php"><img src="<?php  echo $row['image']; ?>" width="33px" class="rounded-circle mt-1"></a>
            </li>
             
              <li class="nav-item">
             <a  class="nav-link" href="ulog.php">Logout</a>
             </li>
           </ul>
        </div>
      </div>
    </nav>
</section>
<br>
<!---------------Add Question Section---------------------------------->

<div  class="container">
  <div class="row">
    <div class="col-sm-6">
    <div  class="jumbotron">
      <h3><i class="fab fa-microblog"></i> Follow Blog Category</h3><hr><br>
      <?php 
        $qry1="SELECT * FROM category";
        $result1=mysqli_query($con,$qry1);
        $row1 = mysqli_fetch_array($result1);
      
        $qry="select * from category";
        $result=mysqli_query($con,$qry);
        while($row=mysqli_fetch_assoc($result)){
        $catid = $row['category_id'];
       ?>
      
       <a href="blog.php"><button type="button" class="btn btn-secondary"><?php echo $row['category_name']; ?></button></a>&nbsp;&nbsp;&nbsp;&nbsp;
       <a href="follow-category.php?id=<?= $catid; ?>" class="btn btn-dark"><i class="fa fa-plus-circle"></i> Follow </a> <span class="label label-success"> <?php $fol =  $row['follower'];  echo abs( $fol); ?> Followers</span> <br><hr>
       <?php

      }

     ?>
</div>
</div>
 <div class="col-sm-0">
    
</div>


     <div class="col-sm-6">
    <div  class="jumbotron">
    <h3 class="text-center"><i class="fas fa-user"></i> Follow User</h3><hr><br>
    <?php
    $qry2="SELECT * FROM user";
    $result2=mysqli_query($con,$qry2);
    $row2 = mysqli_fetch_array($result2);
      
    $qry="select * from user";
    $result=mysqli_query($con,$qry);
    while($row=mysqli_fetch_assoc($result)){
    $catid = $row['fname'];
    ?>
      
       <img src=" <?php  echo $row['image']; ?>" class="img-circle" alt="logo" height="40px">&nbsp;<?php  echo $row['fname']; ?><br><br>
      <a href="follow-user.php?id=<?= $catid; ?>" class="btn btn-dark"><i class="fa fa-plus-circle"></i> Follow </a> <span class="label label-success"> <?php $fol =  $row['follower'];  echo abs( $fol); ?> Followers</span> <br><hr>
       <?php

      }

     ?>
   <div>
     
</div>
 
</div>

</div>

</div>

</div>


<script type="text/javascript">
  

</script>





<!-----------Footer Section------------------->

 <section id="footer">
  <img src="wave2.png" class="footer-img">
  <div class="container">
    <div class="row">
      <div class="col-md-4 footer-box">
        <h4>SenSa</h4><hr>
        <p>It's is a online social interacting platform.Also its a online learning platform of any kind of people.</p>
      </div>
      <div class="col-md-4 footer-box">
        <h4>Contact Us</h4><hr>
        <p>Email: SenSa4578@gmail.com</p>
        <p>Phone: 01639901435</p>
        <p>Phone: 01639901435</p>
        
      </div>
      <div class="col-md-4 footer-box">
             <h4>Follow Social Media</h4><hr>
              <div class="icon">
           <a href=""><img src="facebook.png" height="40" width="40"></a>
         <a href=""><img src="twitter.png" height="50" width="50"></a>
         <a href=""><img src="instagram.png" height="50" width="50"></a>
                </div>
      </div>
      
    </div>
    
  </div>
  
</section>




  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
  

</body>
</html>




