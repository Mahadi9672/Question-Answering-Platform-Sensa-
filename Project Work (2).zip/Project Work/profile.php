<!DOCTYPE html>
<html>
<head>
	<title>SenSa(QA Platform)</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="profile.css">
</head>
<body>

	<!---Navigation Part--->

	

 <section id="navbar-pos">
	<nav class="navbar navbar-expand-lg">
		<div class="container">
			<a href="Home.php" class="navbar-brand">SenSa(Question Answering Platform)</a>
			<button class="navbar-toggler navbar-toggler-right"></button>


			<div>
				<ul class="navbar-nav">
				
					<li class="nav-item">
						<a  class="nav-link" href="notes.php">Blog</a>
					</li>
					
				    <li class="nav-item">
						<a   class="nav-link" href="question.php">Ask a Question</a>
					</li>

					 <li class="nav-item">
						<a   class="nav-link" href="following.php">Follow</a>
					</li>
					<li class="nav-item">
					<a  class="nav-link" href="answer.php">Answer</a>
					</li>

					<li class="nav-item">
					<a  class="nav-link" href="ranking.php">Ranking</a>
					</li>

				        <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><?php 
                    	session_start();
                    	echo $_SESSION['uname'];    
                    	?></a>
						<div class="dropdown-menu dropdown-menu-dark">

                      <a href="profile.php" class="dropdown-item">Profile</a>
						    <a href="#" class="dropdown-item">Question</a>
						    <a href="#" class="dropdown-item">Answer</a>
						    <a href="#" class="dropdown-item">Following</a>
						    <a href="#" class="dropdown-item">Follower</a>
						    <a href="#" class="dropdown-item">Logout</a>
						</div>
					   </li>
					   
                    </ul>
				</div>
			</div>
		</nav>
</section>
<br><br>
<!-------------------------------Sideber------------------->
<div id=About>
	<div class="container">
		<div class="row">
			<div class="col">
				<div id=AboutData>
					<div class="card bg-white">
						<div class="card-title my-5">
							<div class="media">
								<img src="user-icon.png" width="150" class="img-fluid rounded-circle mx-5 d-none d-lg-block">
								<div class="media-body">
									<br>
									<div class="container">
										<table class="table table-responsive ml-4">
											<tr>
												<td class="text-muted">Full Name</td>
												<td>:</td>
												<td>Mahadi Hasan</td>
											</tr>
											<tr>
												<td class="text-muted">User Name</td>
												<td>:</td>
												<td>mahadi72</td>
											</tr>
											<tr>
												<td class="text-muted">Email Address</td>
												<td>:</td>
												<td>mhasan464696@gmail.com</td>
											</tr>
											<tr>
												<td class="text-muted">Password</td>
												<td>:</td>
												<td>12345</td>
											</tr>
											<tr>
												<td class="text-muted">Qualification</td>
												<td>:</td>
												<td>B.Sc Engg in CSE</td>
											</tr>
											<tr>
												<td class="text-muted">Skill</td>
												<td>:</td>
												<td> BASIC C , C++ , java , BOOTSRTAP , HTML , PYTHON</td>
											</tr>
											<tr>
												<td class="text-muted">LOCATION</td>
												<td>:</td>
												<td>Sylhet , Bangladesh</td>
											</tr>
										</table>
										<button type="button" class="btn btn-dark btn-sm">Update Profile</button>
									</div>
								</div>
								
							</div>
							
						</div>
						
					</div>
					
				</div>
				
			</div>
		</div>
		
	</div>
	
</div>









<br><br><br>




<section id="footer">
	<img src="wave2.png" class="footer-img">
	<div class="container">
		<div class="row">
			<div class="col-md-4 footer-box">
				<h4>SenSa</h4><hr>
				<p>We're all spending too much time and energy solving the first iteration of a challenge with the first idea we have. That's both limiting and counterproductive.</p>
			</div>
			<div class="col-md-4 footer-box">
				<h4>Contact Us</h4><hr>
				<p>Email: SenSa4578@gmail.com</p>
				<p>Phone: 01639901435</p>
				<p>Phone: 01639901435</p>
				
			</div>
			<div class="col-md-4 footer-box">
             <h4>Follow Social Media</h4><hr>
              <div class="icon">
			     <a href=""><img src="facebook.png" height=40" width="40"></a>
				 <a href=""><img src="twitter.png" height="50" width="50"></a>
				 <a href=""><img src="instagram.png" height="50" width="50"></a>
                </div>
			</div>
			
		</div>
		
	</div>
	
</section>





	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>