-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Feb 26, 2022 at 04:14 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sensa`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `uname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`uname`, `email`, `password`, `cpassword`) VALUES
('mahadi72', 'mahadi.neub@gmail.com', '1111', '1111'),
('mahfuz_neub', 'mahfuz1245@gmail.com', '1245', '1245'),
('trinoy_neub', 'trinoy501@gmail.com', '8989', '8989');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `ansid` int(11) NOT NULL,
  `details` varchar(255) NOT NULL,
  `quesid` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `upvote` varchar(100) NOT NULL,
  `downvote` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`ansid`, `details`, `quesid`, `uname`, `upvote`, `downvote`) VALUES
(44, '১.জ্বর ২.কাঁশি ৩.শ্বাসকষ্ট', '3', 'mahadi72', '1', '0'),
(46, '<p>kkkkkkkkkkkkkkkk</p>\r\n', '3', 'madihan2020', '0', '1'),
(47, '<p><strong>yyyyyyyyyyyyyyyyyyyyy</strong></p>\r\n', '3', 'mahadi72', '1', '0'),
(48, '<p><strong>mmmmmmmmm</strong></p>\r\n', '3', 'mahadi72', '1', '0'),
(49, '<p>hhhhhhhh</p>\r\n', '3', 'mahadi72', '1', '0'),
(50, '<p>Vatican city</p>\r\n', '27', 'mahfuz_neub', '0', '0'),
(51, '<p>Brahmaputra river</p>\r\n', '28', 'mahfuz_neub', '0', '0'),
(52, '<p>kkkkk</p>\r\n', '3', 'mahadi72', '0', '0'),
(53, '<p>ppppppppppp</p>\r\n', '4', 'mahfuz_neub', '0', '0'),
(54, '<p>llllllll</p>\r\n', '14', 'madihan2020', '0', '0'),
(55, '<p>qqqqqqqqq</p>\r\n', '14', 'trinoy_neub', '0', '0'),
(56, '<p>nnnn</p>\r\n', '15', 'madihan2020', '0', '0'),
(57, '<p>bbbbbb</p>\r\n', '27', 'madihan2020', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blogid` int(11) NOT NULL,
  `head` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `uname` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blogid`, `head`, `details`, `uname`, `category`) VALUES
(1, 'tech', '<p>প্রযুক্তি বলতে কি বুঝায় ?<br />\r\nপ্রযুক্তিবলতে কোন একটি প্রজাতির বিভিন্ন যন্ত্র এবং প্রাকৃতিক উপদান প্রয়োগের ব্যবহারিক জ্ঞানকে বোঝায়। নিজের প্রাকৃতিক পরিবেশের সাথে প্রজাতিটি কেমন খাপ খাওয়াতে পারছে এবং তাকে কিভাবে ব্যবহার করছে তাও নির্ধারণ করে', 'mahadi72', '5'),
(2, 'py', '<p>Python is an interpreted, object-oriented, high-level programming language with dynamic semantics. Its high-level built in data structures, combined with dynamic typing and dynamic binding, make it very attractive for Rapid Application Development.</p>', 'mahadi72', '20'),
(6, 'sc', '<p><strong><em>science, any system of knowledge that is concerned with the physical world and its phenomena and that entails unbiased observations and systematic experimentation. In general, a science involves a pursuit of knowledge covering general truths or the operations of fundamental laws.</em></strong></p>\r\n\r\n<p>&nbsp;</p>\r\n', 'mahadi72', '6');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `follower` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `follower`) VALUES
(5, 'Technology', 2),
(6, 'Science', 1),
(16, 'PHP', 1),
(19, 'JavaScript', 1),
(20, 'Python', 1),
(21, 'Java', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `message`) VALUES
(5, 'Mahin Hassn', 'mahadi.neub@gmail.com', 'fff'),
(6, 'Mahfuz', 'mdshimulahmed873@gmail.com', 'Hello.'),
(7, 'Mahin Hassn', 'mahadi.neub@gmail.com', 'hi');

-- --------------------------------------------------------

--
-- Table structure for table `follow_category`
--

CREATE TABLE `follow_category` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `follower` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `follow_category`
--

INSERT INTO `follow_category` (`id`, `category`, `follower`, `time`) VALUES
(5, '5', 'madihan2020', '2022-01-25 12:01:30'),
(10, '5', 'mahadi72', '2022-01-25 12:40:56'),
(12, '6', 'mahadi72', '2022-01-25 15:01:13'),
(13, 'Mahin', 'madihan2020', '2022-01-25 16:27:10'),
(15, '19', 'mahfuz_neub', '2022-01-25 20:59:09'),
(16, 'Mahfuz', 'mahfuz_neub', '2022-01-25 20:59:14'),
(24, 'Mahfuz', 'mahadi72', '2022-01-26 23:49:39'),
(26, '2', 'mahadi72', '2022-01-26 23:52:56'),
(27, '1', 'mahadi72', '2022-01-26 23:53:12'),
(30, '16', 'mahadi72', '2022-01-26 23:57:38'),
(31, 'Mahin', 'mahadi72', '2022-01-26 23:57:40'),
(33, '21', 'mahadi72', '2022-01-27 00:03:46'),
(36, '20', 'mahadi72', '2022-02-02 19:55:21');

-- --------------------------------------------------------

--
-- Table structure for table `follow_user`
--

CREATE TABLE `follow_user` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `follower` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `follow_user`
--

INSERT INTO `follow_user` (`id`, `fname`, `follower`, `time`) VALUES
(5, 'Mahin', 'madihan2020', '2022-01-27 00:06:21'),
(6, 'Mahfuz', 'madihan2020', '2022-01-27 00:06:23'),
(7, 'Md Mahadi Hasan', 'madihan2020', '2022-01-27 00:06:27'),
(16, 'Mahfuz', 'mahadi72', '2022-01-29 22:29:08'),
(17, 'Md Mahadi Hasan', 'mahadi72', '2022-01-29 22:29:12'),
(18, 'Ahmed', 'trinoy_neub', '2022-01-29 23:25:22');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `quesid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `details` varchar(2552) NOT NULL,
  `uname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`quesid`, `title`, `details`, `uname`) VALUES
(3, '', 'নভেল করোনাভাইরাস এর লক্ষণ গুলো কি কি?', 'madihan2020'),
(4, 'ব্লগ', 'ব্লগ কে আকর্ষনীয় করে তুলতে কি কি প্রয়োজন ?', 'mahadi72'),
(14, 'ttttttttttttt', 'what is your question ?', 'mahadi72'),
(15, 'question', 'What do you mean by programming?', 'mahadi72'),
(18, 'gggggggggggg', '<p>wwwwwwwwwwwwwwwwwwwwwww</p>\r\n', 'mahadi72'),
(19, 'qqqqqqqq', '<p>ccccccccccccccccccccc</p>\r\n', 'mahadi72'),
(21, 'jjj', '<p>jjjjjjjjjj</p>\r\n', 'mahfuz_neub'),
(27, 'ques', '<p><strong>Which is the smallest country in earth?</strong></p>\r\n', 'madihan2020'),
(28, 'top', '<p><em>Which river of bangladesh originates in tibet?</em></p>\r\n', 'madihan2020'),
(29, 'pppppp', '<p>jjjjjjjjjjjj</p>\r\n', 'mahadi72'),
(30, 'rrr', '<p>qqqqqqqqqqqq</p>\r\n', 'mahadi72');

-- --------------------------------------------------------

--
-- Table structure for table `ranking`
--

CREATE TABLE `ranking` (
  `id` int(11) NOT NULL,
  `total_question` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ranking`
--

INSERT INTO `ranking` (`id`, `total_question`, `user_name`) VALUES
(258, '5', 'mahadi72'),
(259, '3', 'mahfuz_neub'),
(261, '1', 'trinoy_neub'),
(263, '4', 'madihan2020');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `fname` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `skill` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `follower` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`fname`, `uname`, `email`, `password`, `cpassword`, `qualification`, `skill`, `location`, `image`, `follower`) VALUES
('Mahin', 'madihan2020', 'madihan2020@gmail.com', 'madihan', 'madihan', 'MBBS DOCTOR', 'java,php,html.', 'Hazrat Shahjalal Road Amberkhana, Sylhet.', 'user-icon.png', 1),
('Mahfuz', 'mahfuz_neub', 'mahfuz1245@gmail.com', '123', '123', '', '', '', 'default.png', 2),
('Md Mahadi Hasan', 'mahadi72', 'mhasan464696@gmail.com', '12345', '12345', 'BSC Enggineering in CSE', 'Basic C.C++,Java,Python', 'Sylhet Bangladesh', 'boy.jpg', 2),
('Ahmed', 'trinoy_neub', 'trinoy501@gmail.com', '3636', '3636', 'bsc engg', 'c', 'Sylhet Bangladesh', 'instagram.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vote`
--

CREATE TABLE `vote` (
  `id` int(11) NOT NULL,
  `question_id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `vote` int(100) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote`
--

INSERT INTO `vote` (`id`, `question_id`, `user_id`, `vote`, `time`) VALUES
(2, '3', 'abdullah', 0, '2022-01-02 01:13:22'),
(11, '14', 'madihan2020', 0, '2022-01-02 23:55:16'),
(12, '3', 'madihan2020', 1, '2022-01-02 23:55:22'),
(16, '15', 'mahadi72', 1, '2022-01-03 11:24:14'),
(18, '4', 'mahfuz_neub', 1, '2022-01-06 23:26:37'),
(19, '14', 'mahfuz_neub', 1, '2022-01-06 23:26:40'),
(21, '16', 'mahfuz_neub', 0, '2022-01-06 23:26:49'),
(23, '18', 'mahfuz_neub', 1, '2022-01-06 23:27:03'),
(24, '3', 'mahfuz_neub', 1, '2022-01-07 00:11:01'),
(26, '22', 'mahadi72', 0, '2022-01-15 21:55:21'),
(27, '20', 'mahadi72', 1, '2022-01-17 22:58:41'),
(32, '3', 'mahadi72', 0, '2022-01-22 22:49:24'),
(34, '24', 'mahadi72', 1, '2022-01-22 23:16:48'),
(36, '4', 'mahadi72', 0, '2022-01-23 00:23:52'),
(37, '14', 'mahadi72', 1, '2022-01-25 14:06:39'),
(38, '18', 'mahadi72', 0, '2022-01-29 22:27:53'),
(39, '19', 'mahadi72', 1, '2022-01-29 22:28:09');

-- --------------------------------------------------------

--
-- Table structure for table `vote_ans`
--

CREATE TABLE `vote_ans` (
  `id` int(11) NOT NULL,
  `quesid` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `vote` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote_ans`
--

INSERT INTO `vote_ans` (`id`, `quesid`, `user_id`, `vote`, `time`) VALUES
(24, '46', 'mahadi72', '1', '2022-01-28 01:13:48'),
(26, '47', 'mahadi72', '1', '2022-01-28 01:15:23'),
(36, '48', 'mahadi72', '1', '2022-01-28 01:23:57'),
(37, '49', 'mahadi72', '1', '2022-01-28 01:24:10'),
(40, '44', 'mahadi72', '1', '2022-01-28 01:33:01');

-- --------------------------------------------------------

--
-- Table structure for table `vote_blog`
--

CREATE TABLE `vote_blog` (
  `id` int(11) NOT NULL,
  `blogid` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `vote` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote_blog`
--

INSERT INTO `vote_blog` (`id`, `blogid`, `user_id`, `vote`, `time`) VALUES
(54, '12', 'mahadi72', '0', '2022-01-27 01:21:44'),
(55, '11', 'mahadi72', '0', '2022-01-27 01:21:52'),
(58, '8', 'mahadi72', '0', '2022-01-27 20:15:52'),
(67, '2', 'mahadi72', '0', '2022-01-30 23:04:44'),
(68, '1', 'mahadi72', '1', '2022-01-30 23:04:55'),
(70, '6', 'mahadi72', '0', '2022-01-31 00:49:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`uname`);

--
-- Indexes for table `answer`
--
ALTER TABLE `answer`
  ADD PRIMARY KEY (`ansid`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blogid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `follow_category`
--
ALTER TABLE `follow_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `follow_user`
--
ALTER TABLE `follow_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`quesid`);

--
-- Indexes for table `ranking`
--
ALTER TABLE `ranking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `vote`
--
ALTER TABLE `vote`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vote_ans`
--
ALTER TABLE `vote_ans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vote_blog`
--
ALTER TABLE `vote_blog`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answer`
--
ALTER TABLE `answer`
  MODIFY `ansid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `blogid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `follow_category`
--
ALTER TABLE `follow_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `follow_user`
--
ALTER TABLE `follow_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `quesid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `ranking`
--
ALTER TABLE `ranking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=264;

--
-- AUTO_INCREMENT for table `vote`
--
ALTER TABLE `vote`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `vote_ans`
--
ALTER TABLE `vote_ans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `vote_blog`
--
ALTER TABLE `vote_blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
