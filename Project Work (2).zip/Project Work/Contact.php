<!DOCTYPE html>
<html>
<head>
	<title>SenSa(QA Platform)</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="Style.css">
	<script src="ckeditor/ckeditor.js"></script>
</head>
<body>

	<!---Navigation Part--->

  <section id="navbar-pos">
	<nav class="navbar navbar-expand-lg navbar-light bg-info">
		<div class="container">
			<a href="Home.php" class="navbar-brand"><img src="">SenSa(Question Answering Platform)</a>
			<button class="navbar-toggler navbar-toggler-right"></button>

			<div>
				<ul class="navbar-nav">
					<li class="nav-item">
						<a  class="nav-link" href="Home.php">Home</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="About.php">About Us</a>
					</li>

                     <li class="nav-item">
						<a  class="nav-link" href="Login.php">Login</a>
					</li>
					
				    <li class="nav-item">
						<a   class="nav-link" href="Signup.php">Sign-Up</a>
					</li>

					<li class="nav-item">
						<a   class="nav-link" href="Contact.php">Contact</a>
					</li>
					
				</ul>
			</div>
			
		</div>
	</nav>
</section>

<br><br>
   
	<section id="Contact" class="py-5 bg-light">
		<div  class="jumbotron">
		<div class="container">
			<div class="row">
				<div class="col-lg-9">
					<div class="info-contact">
						 <?php if(isset($_REQUEST['info'])){?>
	                     <?php if($_REQUEST['info']=="added"){?>
	               <div class="alert alert-success" role="alert">
		           Record Submit Successfully.
	            </div>
	       <?php } ?>
	      <?php } ?>
						<h2 class="display-4 text-success">Get In Touch</h2>
						<p class="lead text-dark">We are here to serve you.For any query fill the form.</p><hr>
						
					</div><br><br>
					<form action="contact_us.php" method="post">
						<div>
							<input type="text" name="name" placeholder="Name" class="form-control form-control-lg" required>
						</div><br>

						<div>
							<input type="email" name="email" placeholder="Email Address" class="form-control form-control-lg" required></div><br>
							
							<textarea name="message" id="editor" rows="5" class="form-control form-control-lg" placeholder="Your Message" required></textarea><br>

							<button type="submit" class="btn btn-dark btn-sm">Submit</button>
					</form>
					
				</div>
				
			</div>
			
		</div>
	</div>
		
	</section>
   
   
<br><br><br>

<!-----------Footer Section------------------->

<section id="footer">
	<img src="wave2.png" class="footer-img">
	<div class="container">
		<div class="row">
			<div class="col-md-4 footer-box">
				<h4>SenSa</h4><hr>
				<p>It's is a online social interacting platform. Also its a online learning platform of any kind of people.</p>
			</div>
			<div class="col-md-4 footer-box">
				<h4>Contact Us</h4><hr>
				<p>Email: SenSa4578@gmail.com</p>
				<p>Phone: 01639901435</p>
				<p>Phone: 01639901435</p>
				
			</div>
			<div class="col-md-4 footer-box">

				<h4>Follow Social Media</h4><hr>

				<div class="icon">
				<a href=""><img src="facebook.png" height=40" width="40"></a>
				 <a href=""><img src="twitter.png" height="50" width="50"></a>
				 <a href=""><img src="instagram.png" height="50" width="50"></a>
				</div>
			</div>
			
		</div>
		
	</div>
	
</section>







	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>