

 <?php

   $con=mysqli_connect('localhost:3307','root','','sensa');
    if(isset($_POST['submit'])){
      $a=$_POST['title'];
      $b=$_POST['details'];
      //$session_image = $_SESSION['image'];
      $session_user_name = $_SESSION['uname'];


    echo "$a";
    echo "$b";
    echo "$session_user_name";
    //echo "$session_image";
   
      $qry="INSERT INTO question(title,details,upvote,downvote,uname) VALUES ('$a','$b','0','0','$session_user_name')";
      mysqli_query($con,$qry);




      header("Location: question.php?info=added");
      exit();
      

      }
?>

