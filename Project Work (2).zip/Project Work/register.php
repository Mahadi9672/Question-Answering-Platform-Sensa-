

<?php
session_start();
$con=mysqli_connect('localhost:3307','root','');
mysqli_select_db($con,'sensa');
$fname=$_POST['fname'];
$uname=$_POST['uname'];
$email=$_POST['email'];
$image=$_POST['image'];
$password=$_POST['password'];
$cpassword=$_POST['cpassword']; 

$s="select * from user where uname='$uname'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);

if($num==1){
	echo "<br>";
	echo '<script>alert("User_Name Already Taken.Try with another one")</script>';
	
}	
else{
    $rr="insert into user(fname,uname,email,image,password,cpassword) values ('$fname','$uname','$email','$image','$password','$cpassword')";
	mysqli_query($con,$rr);
	echo "<br>";
	header("Location: Signup.php?info=added");
		exit();
	
	
}
?>




