<?php
session_start();
$con=mysqli_connect('localhost:3307','root','');
mysqli_select_db($con,'sensa');
$uname=$_POST['uname'];
$email=$_POST['email'];
$password=$_POST['password'];
$cpassword=$_POST['cpassword']; 

$s="select * from admin where uname='$uname'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);

if($num==1){
	echo "<br>";
	echo '<script>alert("User_Name Already Taken.Try with another one")</script>';
	
}	
else{
    $rr="insert into admin(uname,email,password,cpassword) values ('$uname','$email','$password','$cpassword')";
	mysqli_query($con,$rr);
	echo "<br>";
	echo '<script>alert("Your Registration Successfully.Please Login and Access our Website.")</script>';
	
}
?>




