<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'sensa');
?>


<!DOCTYPE html>
<html>
<head>
	<title>Admin Panel</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="addcategories.css">
</head>
<body>
	<!---Navigation Part--->

	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="adminpanel.php" class="navbar-brand">Admin Panel (SenSa)</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					  <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Category</a>
						<div class="dropdown-menu dropdown-menu-dark">

                       <a href="addcategories.php" class="dropdown-item">Add Category</a>
					   <a href="allcategory.php" class="dropdown-item">Delete Category</a>
						  
						</div>
					   </li>

					   <li class="nav-item">
						<a  class="nav-link" href="manageuser.php">Manage User</a>
					</li>

					<li class="nav-item">
						<a  class="nav-link" href="contact-info.php">Contact info</a>
					</li>

					<li class="nav-item">
						  <?php
              $session_user_name = $_SESSION['uname'];
              $qry="select * from admin where uname='$session_user_name'";
              $result=mysqli_query($con,$qry);
              $row=mysqli_fetch_assoc($result);
              ?>
            <button class="btn btn-success"><?php  echo $row['uname']; ?></button>
						
					</li>



           



					<li class="nav-item">
						<a  class="nav-link" href="logout.php">Logout</a>
					</li>

					
										
				</ul>
			</div>
			
		</div>
	</nav>
	<br><br>
     
	 <div class="card-body">
	 <h2>All Category List</h2><br>
	 <?php if(isset($_REQUEST['info'])){?>
	<?php if($_REQUEST['info']=="added"){?>
	<div class="alert alert-success" role="alert">
		Category Deleted Successfully.
	</div>
	<?php } ?>
	<?php } ?>

	<table class="table table-hover table-bordered table-secondary table-sm">
    <tr class="table-info">
    	<th class="text-center">Category ID</th>
		<th class="text-center">Category Name</th>
		<th class="text-center">Delete</th>
		
		
</tr>

	<?php
		$qry="select * from category";
		$result=mysqli_query($con,$qry);
		while($row=mysqli_fetch_assoc($result)){
	?>	
	<tr>
		<th class="text-center"><?php echo $row['category_id']; ?></th> 
		<th class="text-center"><?php echo $row['category_name']; ?></th>
	
		<th class="text-center"><a class="btn btn-dark" href="delete category.php?rn=<?php echo $row['category_id'];?>">Delete</a></th>
		
		
		
</tr>

    <?php

		}

	?>
	
	</table>

</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>


</body>
</html>

