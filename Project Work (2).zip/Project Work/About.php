<!DOCTYPE html>
<html>
<head>
	<title>SenSa(QA Platform)</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="About.css">
</head>
<body>

	<!---Navigation Part--->
  <section id="navbar-pos">
	<nav class="navbar navbar-expand-lg navbar-light bg-info">
		<div class="container">
			<a href="Home.php" class="navbar-brand"><img src="">SenSa(Question Answering Platform)</a>
			<button class="navbar-toggler navbar-toggler-right"></button>

			<div>
				<ul class="navbar-nav">
					<li class="nav-item">
						<a  class="nav-link" href="Home.php">Home</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="About.php">About Us</a>
					</li>

                     <li class="nav-item">
						<a  class="nav-link" href="Login.php">Login</a>
					</li>
					
				    <li class="nav-item">
						<a   class="nav-link" href="Signup.php">Sign-Up</a>
					</li>

					<li class="nav-item">
						<a   class="nav-link" href="Contact.php">Contact</a>
					</li>
					
				</ul>
			</div>
			
		</div>
	</nav>
</section>

<!-----------About Header------------------------>

<section id="head" class="text-center text-light">
		<div class="container">
			<div class="row">
				<div class="col mt-4 pt-4">
					<h2>About Us</h2>
					<p class="lead">Hello,Welcome to Visit Our Website</p>
					
				</div>
				
			</div>
			
		</div>
		
	</section>



<!-----About Info-------->
  
	<section id="info" class="py-5">
		<div class="container"><hr>
			<div class="row">
				<div class="col-md-6">
					<h4>About SenSa(Question Answering Platform)</h4>
					<p class="lead">Our Project name is SenSa. The main goal of our project is become a online 
					learning platform for any kind of people. In our website user can ask a question and can get 
					solution from other user. A user can write blog post,tutorial,biography etc. User can follow
					blog category and also can follow other user. User can react using upvote and downvote on question,
				    answer and blog.</p>
					
				</div>
				<div class="col-md-6 text-right">
					<img src="3.jpg" class="img-fluid rounded"  width="430px">
					
				</div>
				
			</div><br><hr>
			
		</div>
		
	</section>
<!--------------------------Project Developer--------------------------->
<section>

	<div class="container">
			<div class="row">
				<h5 class="text-center display-6">Project Developer</h5><br><br><br><hr>
				<div class="col-md-4 text-center">
					<img src="Pranta_Sarker.jpg" class="img-fluid rounded-circle" width="150">
					
				</div>
				<div class="col-md-4 text-center">
					<img src="Mahadi.jpg" class="img-fluid rounded-circle"  width="150">
				</div>
				<div class="col-md-4 text-center">
					<img src="Mahfuz.jpg" class="img-fluid rounded-circle"  width="150">
				</div>
				</div>

				<div class="row">
			    <div class="col-md-4 text-center">
				<h5>Name : Pranta Sarkar</h5>
                <h5>Project Supervisor</h5>
                <h5>Department Of CSE</h5>
					
				</div>
			    <div class="col-md-4 text-center">
					<h5>Name : Mahadi Hasan</h5>
                    <h5>Studying at CSE in Neub</h5>
                    <h5>Session : 2018-2022</h5>
					
				</div>
				<div class="col-md-4 text-center">
					<h5>Name : Mahfuz Hussain Shimul</h5>
                    <h5>Studying at CSE in Neub</h5>
                    <h5>Session : 2018-2022</h5>
				</div>
				</div><hr>
		</div>
	
</section><br><br><br>

<!-----------Footer Section------------------->

<section id="footer">
	<img src="wave2.png" class="footer-img">
	<div class="container">
		<div class="row">
			<div class="col-md-4 footer-box">
				<h4>SenSa</h4><hr>
				<p>It's is a online social interacting platform. Also its a online learning platform of any kind of people.</p>
			</div>
			<div class="col-md-4 footer-box">
				<h4>Contact Us</h4><hr>
				<p>Email: SenSa4578@gmail.com</p>
				<p>Phone: 01639901435</p>
				<p>Phone: 01639901435</p>
				
			</div>
			<div class="col-md-4 footer-box">

				<h4>Follow Social Media</h4><hr>

				<div class="icon">
				<a href=""><img src="facebook.png" height=40" width="40"></a>
				 <a href=""><img src="twitter.png" height="50" width="50"></a>
				 <a href=""><img src="instagram.png" height="50" width="50"></a>
				</div>
			</div>
			
		</div>
		
	</div>
	
</section>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>