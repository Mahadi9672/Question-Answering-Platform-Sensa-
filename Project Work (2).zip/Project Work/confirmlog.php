<?php
session_start();
$con=mysqli_connect('localhost:3307','root','');
mysqli_select_db($con,'sensa');

$uname=$_POST['uname'];
$password=$_POST['password'];


$s="select * from admin where uname='$uname' && password='$password'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);

if($num==1){
	$n=mysqli_query($con,"select * from admin where uname='$uname' && password='$password'");
	$row=mysqli_fetch_assoc($n);
	header('location:adminpanel.php');
	$_SESSION['uname']=$uname;
	
}
else{
	
	echo '<script>alert("You Are Not Register")</script>';
	//header('location:adminlogin.php');
}
?>