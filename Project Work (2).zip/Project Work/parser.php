<?php
  session_start();
  $con=mysqli_connect('localhost:3307','root','');
  mysqli_select_db($con,'sensa');
  extract($_GET);
  if(isset($_GET['follow'])){
    echo $follow_info=$_GET['follow'];
  }
$session_user_name=$_SESSION['uname'];
$query="INSERT INTO follow_category('follow_info','following') VALUES('$follow_info','$session_user_name')";
?>