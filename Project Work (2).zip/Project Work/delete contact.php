<?php
    session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'sensa');


	$id=$_GET['rn'];
	$query="delete from contact where id='$id'";
	$data=mysqli_query($con,$query);
	if($data){
	header("Location: contact-info.php?info=added");
	exit();
	}
	else{
	echo "<br>";
	echo "<h1><center>Failed to delete</h1></center>";
	}
	?>