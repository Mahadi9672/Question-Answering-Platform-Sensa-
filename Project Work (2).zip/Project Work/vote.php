<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','','sensa');
?>

<?php
    $quesid = $_GET['id'];
    $v = $_GET['v'];
    $user=$_SESSION['uname'];
    $data = "SELECT * FROM `vote` WHERE question_id = '$quesid' AND user_id = '$user'";
    $result = mysqli_query($con, $data);
    $row = mysqli_fetch_array($result);
    $ver = mysqli_num_rows($result);

    if ($ver > 0) {
        $del = "DELETE FROM vote WHERE question_id = '$quesid' AND user_id= '$user'";
        $del_f = mysqli_query($con, $del);
        header("location: upage.php");
    }
        if($v != $row['vote']){
            $vote = "INSERT INTO vote (`question_id`, `user_id`, `vote`, `time`) VALUES ('$quesid', '$user', $v, NOW())";
            $vote_f = mysqli_query($con, $vote);
            header("location: upage.php");
        }
    
    
?>