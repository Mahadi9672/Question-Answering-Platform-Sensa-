<?php
    session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'sensa');


	$uname=$_GET['rn'];
	$query="delete from user where uname='$uname'";
	$data=mysqli_query($con,$query);
	if($data){
	header("Location:manageuser.php?info=added");
	exit();
	}
	else{
	echo "<br>";
	echo "<h1><center>Failed to delete</h1></center>";
	}
	?>