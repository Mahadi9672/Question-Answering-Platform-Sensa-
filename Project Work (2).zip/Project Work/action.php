<?php  
session_start();
$con=mysqli_connect('localhost:3307','root','');
mysqli_select_db($con,'sensa');
$session_user_name=$_SESSION['uname'];

function make_follow_button($con, $session_user_name, $receiver_id)
{
 $query = "SELECT * FROM tbl_follow WHERE sender_id = '".$sender_id."' AND receiver_id = '".$receiver_id."'";
 $statement = $connect->prepare($query);
 $statement->execute();
 $total_row = $statement->rowCount();
 $output = '';
 if($total_row > 0)
 {
  $output = '<button type="button" name="follow_button" class="btn btn-warning action_button" data-action="unfollow" data-sender_id="'.$sender_id.'"> Following</button>';
 }
 else
 {
  $output = '<button type="button" name="follow_button" class="btn btn-info action_button" data-action="follow" data-sender_id="'.$sender_id.'"><i class="glyphicon glyphicon-plus"></i> Follow</button>';
 }
 return $output;
}

?>