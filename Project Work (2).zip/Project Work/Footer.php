<section id="footer">
	<img src="wave2.png" class="footer-img">
	<div class="container">
		<div class="row">
			<div class="col-md-4 footer-box">
				<h4>SenSa</h4><hr>
				<p>We're all spending too much time and energy solving the first iteration of a challenge with the first idea we have. That's both limiting and counterproductive.</p>
			</div>
			<div class="col-md-4 footer-box">
				<h4>Contact Us</h4><hr>
				<p>Email: SenSa4578@gmail.com</p>
				<p>Phone: 01639901435</p>
				<p>Phone: 01639901435</p>
				
			</div>
			<div class="col-md-4 footer-box">
             <h4>Follow Social Media</h4><hr>
              <div class="icon">
			     <a href=""><img src="facebook.png" height=40" width="40"></a>
				 <a href=""><img src="twitter.png" height="50" width="50"></a>
				 <a href=""><img src="instagram.png" height="50" width="50"></a>
                </div>
			</div>
			
		</div>
		
	</div>
	
</section>