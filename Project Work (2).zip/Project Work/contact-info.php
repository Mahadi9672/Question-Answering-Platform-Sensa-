<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'sensa');
?>


<!DOCTYPE html>
<html>
<head>
	<title>Admin Panel</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="addcategories.css">
</head>
<body>
	<!---Navigation Part--->

	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="adminpanel.php" class="navbar-brand">Admin Panel (SenSa)</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					  <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Category</a>
						<div class="dropdown-menu dropdown-menu-dark">

                       <a href="addcategories.php" class="dropdown-item">Add Category</a>
					   <a href="allcategory.php" class="dropdown-item">Delete Category</a>
						  
						</div>
					   </li>

					   <li class="nav-item">
						<a  class="nav-link" href="manageuser.php">Manage User</a>
					</li>

					<li class="nav-item">
						<a  class="nav-link" href="contact-info.php">Contact info</a>
					</li>

					<li class="nav-item">
						  <?php
              $session_user_name = $_SESSION['uname'];
              $qry="select * from admin where uname='$session_user_name'";
              $result=mysqli_query($con,$qry);
              $row=mysqli_fetch_assoc($result);
              ?>
            <button class="btn btn-success"><?php  echo $row['uname']; ?></button>
						
					</li>



           



					<li class="nav-item">
						<a  class="nav-link" href="logout.php">Logout</a>
					</li>

					
										
				</ul>
			</div>
			
		</div>
	</nav>
	<!-----------Contact Details--------------------->

	<br><br>
	<?php if(isset($_REQUEST['info'])){?>
	<?php if($_REQUEST['info']=="added"){?>
	<div class="alert alert-success" role="alert">
		Record Deleted Successfully.
	</div>
	<?php } ?>
	<?php } ?>
	 <div class="card-body">
	 	                         
	<table class="table table-hover table-bordered table-secondary table-lg">
    <tr class="table-info">
    	<h2>All Contact List</h2><br>
   
    	<th class="text-center">Contact ID</th>
		<th class="text-center">Name</th>
		<th class="text-center">Email</th>
		<th class="text-center">Message</th>
		<th class="text-center">Operation</th>
		
		
</tr>

	<?php
		$qry="select * from contact";
		$result=mysqli_query($con,$qry);
		while($row=mysqli_fetch_assoc($result)){
	?>	
	<tr>
		<th class="text-center"><?php echo $row['id']; ?></th> 
		<th class="text-center"><?php echo $row['name']; ?></th>
		<th class="text-center"><?php echo $row['email']; ?></th>
		<th class="text-center"><?php echo $row['message'];?></th>

		<th class="text-center"><a class="btn btn-dark" href="delete contact.php?rn=<?php echo $row['id'];?>">Delete</a></th>
		
		
		
</tr>

    <?php

		}

	?>
	
	</table>
	</table>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>


</body>
</html>