<?php
    session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'sensa');


	$quesid=$_GET['quesid'];
	$query="delete from question where quesid='$quesid'";
	$data=mysqli_query($con,$query);
	if($data){
	header("Location: mypic.php?info=added");
	exit();
	}
	else{
	echo "<br>";
	echo "<h1><center>Failed to delete</h1></center>";
	}
	?>
