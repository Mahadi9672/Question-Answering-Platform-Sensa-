<!DOCTYPE html>
<html>
<head>
	<title>SenSa(QA Platform)</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<!---Navigation Part--->

  <section id="navbar-pos">
	<nav class="navbar navbar-expand-lg navbar-light bg-info">
		<div class="container">
			<a href="Home.php" class="navbar-brand"><img src="">SenSa(Question Answering Platform)</a>
			<button class="navbar-toggler navbar-toggler-right"></button>

			<div>
				<ul class="navbar-nav">
					<li class="nav-item">
						<a  class="nav-link" href="Home.php">Home</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="About.php">About Us</a>
					</li>

                     <li class="nav-item">
						<a  class="nav-link" href="Login.php">Login</a>
					</li>
					
				    <li class="nav-item">
						<a   class="nav-link" href="Signup.php">Sign-Up</a>
					</li>

					<li class="nav-item">
						<a   class="nav-link" href="Contact.php">Contact</a>
					</li>
					
				</ul>
			</div>
			
		</div>
	</nav>
</section>
<!---------Login------------>
<br><br>
    
	<section class="container-fluid">
	<section class="row justify-content-center">

	<section class="col-12 clo-sm-6 col-md-3 mt-5">
	<form class="form-container" action="validation.php" method="post">
    <h1 class="text-center">User Login</h1><hr><br>
    <div class="form-group">
    <label for="username" class="text-primary" >User Name</label>
    <input type="username" class="form-control" name="uname" required>
    </div>

  <br>
  <div class="form-group">
    <label for="Password" class="text-primary">Password</label>
    <input type="password" class="form-control" name="password" required>
  </div><br>
  
   
 
  <button type="submit" class="btn btn-dark btn-sm">Login</button>
  <button class="btn btn-dark btn-sm " type="reset" value="Reset">Reset</button>

</form>
</section>
</section>
</section>
<br><br><br>


<!-----------Footer Section------------------->

<section id="footer">
	<img src="wave2.png" class="footer-img">
	<div class="container">
		<div class="row">
			<div class="col-md-4 footer-box">
				<h4>SenSa</h4><hr>
				<p>It's is a online social interacting platform. Also its a online learning platform of any kind of people.</p>
			</div>
			<div class="col-md-4 footer-box">
				<h4>Contact Us</h4><hr>
				<p>Email: SenSa4578@gmail.com</p>
				<p>Phone: 01639901435</p>
				<p>Phone: 01639901435</p>
				
			</div>
			<div class="col-md-4 footer-box">

				<h4>Follow Social Media</h4><hr>

				<div class="icon">
				<a href=""><img src="facebook.png" height="40" width="40"></a>
				 <a href=""><img src="twitter.png" height="50" width="50"></a>
				 <a href=""><img src="instagram.png" height="50" width="50"></a>
				</div>
			</div>
			
		</div>
		
	</div>
	
</section>







	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>