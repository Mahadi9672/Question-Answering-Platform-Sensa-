<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'sensa');
	$session_user_name=$_SESSION['uname'];
?>

<?php

if(isset($_POST['type']) && $_POST['type']!='' && isset($_POST['quesid']) 
&& $_POST['quesid']>0){
	$type=mysqli_real_escape_string($con,$_POST['type']);
	$quesid=mysqli_real_escape_string($con,$_POST['quesid']);

		if($type=='upvote'){
			if(isset($_COOKIE['upvote_'.$quesid])){
			   setcookie('upvote_'.$quesid,"yes",1);
			   $sql="UPDATE question set upvote=upvote-1 where quesid='$quesid'";
			   $operation="unupvote";
			}else{

                if(isset($_COOKIE['downvote_'.$quesid])){
			    setcookie('downvote_'.$quesid,"yes",1);
			    mysqli_query($con,"UPDATE question set downvote=downvote-1 where quesid='$quesid'");
			   
			   }



				setcookie('upvote_'.$quesid,"yes",time(0.1));
				$sql="UPDATE question set upvote=upvote+1 where quesid='$quesid'";
				$sql2="INSERT into  questionlike (questionid,email,liketype) VALUES ('$quesid','$session_user_name','upvote')";
				$operation="upvote";
			}
			
		}

		if($type=='downvote'){
			if(isset($_COOKIE['downvote_'.$quesid])){
			   setcookie('downvote_'.$quesid,"yes",1);
			   $sql="UPDATE question set downvote=downvote-1 where quesid='$quesid'";
			    $operation="undownvote";
			}else{

                 if(isset($_COOKIE['upvote_'.$quesid])){
			    setcookie('upvote_'.$quesid,"yes",1);
			    mysqli_query($con,"UPDATE question set upvote=upvote-1 where quesid='$quesid'");
			   
			   }





				setcookie('downvote_'.$quesid,"yes",time()+60*60*24*365*5);
				$sql="UPDATE question set downvote=downvote+1 where quesid='$quesid'";
				  $operation="downvote";
			}
			
		}
		mysqli_query($con,$sql);
		mysqli_query($con,$sql2);
		$row=mysqli_fetch_assoc(mysqli_query($con,"select * from question where quesid='$quesid'"));

		
}

?>