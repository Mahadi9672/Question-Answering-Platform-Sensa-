<?php
  session_start();
  $con=mysqli_connect('localhost:3307','root','','sensa');
?>

<?php
    $catid = $_GET['id'];
    $user=$_SESSION['uname'];

    $cat = "SELECT * FROM user WHERE fname='$catid'";
    $cat_f = mysqli_query($con, $cat);
    $cat_query = mysqli_fetch_array($cat_f);
    $cat_follower = $cat_query['follower'];

    $query = "SELECT * FROM `follow_user` WHERE fname='$catid' AND follower='$user'";
    $query_f = mysqli_query($con, $query);
    $num = mysqli_num_rows($query_f);

    if($num > 0){
      $del = "DELETE FROM follow_user WHERE fname='$catid' AND follower='$user'";
      $del_f = mysqli_query($con, $del);
      $sub_query = "UPDATE user SET follower = follower - 1 WHERE fname = '".$catid."'";
        $q = mysqli_query($con, $sub_query);
    }else{
      $data = "INSERT INTO `follow_user`(`fname`, `follower`, `time`) VALUES ('$catid','$user',NOW())";
        $del_f = mysqli_query($con, $data);
        $sub_query = "UPDATE user SET follower = follower + 1 WHERE fname = '".$catid."'";
        $q = mysqli_query($con, $sub_query);
    }

      
        header("location: following.php");

    
    
    
?>