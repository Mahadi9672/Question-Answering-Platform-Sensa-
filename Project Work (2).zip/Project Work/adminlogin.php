<!DOCTYPE html>
<html>
<head>
  <title>SenSa(QA Platform)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>

  <div class="sign">
    <img src="user-icon.png" width="100px">
    <h1>Admin Login</h1>
    <form action="confirmlog.php" method="post">
    <div class="form-group">
    <input type="username" name="uname" class="form-control" id="user" aria-describedby="user" placeholder="User Name" required="">
    <br>
    <input type="password" name="password" class="form-control" id="Password1" placeholder="Password" required="">
    </div><br>
     <button type="submit" class="btn btn-primary">Login</button>
     <br><br>
    <p>Don't have an account?<a href="admin.php">Signup</a></p>
     </form>
  </div>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>