<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'sensa');
	$session_user_name=$_SESSION['uname'];
?>

<?php

if(isset($_POST['type']) && $_POST['type']!='' && isset($_POST['blogid']) 
&& $_POST['blogid']>0){
	$type=mysqli_real_escape_string($con,$_POST['type']);
	$blogid=mysqli_real_escape_string($con,$_POST['blogid']);

		if($type=='upvote'){
			if(isset($_COOKIE['upvote_'.$blogid])){
			   setcookie('upvote_'.$blogid,"yes",1);
			   $sql="UPDATE blog set upvote=upvote-1 where blogid='$blogid'";
			   $operation="unupvote";
			}else{

                if(isset($_COOKIE['downvote_'.$blogid])){
			    setcookie('downvote_'.$blogid,"yes",1);
			    mysqli_query($con,"UPDATE blog set downvote=downvote-1 where blogid='$blogid'");
			   
			   }



				setcookie('upvote_'.$blogid,"yes",time()+60*60*24*365*5);
				$sql="UPDATE blog set upvote=upvote+1 where blogid='$blogid'";
				$operation="upvote";
			}
			
		}

		if($type=='downvote'){
			if(isset($_COOKIE['downvote_'.$blogid])){
			   setcookie('downvote_'.$blogid,"yes",1);
			   $sql="UPDATE blog set downvote=downvote-1 where blogid='$blogid'";
			    $operation="undownvote";
			}else{

                 if(isset($_COOKIE['upvote_'.$blogid])){
			    setcookie('upvote_'.$blogid,"yes",1);
			    mysqli_query($con,"UPDATE blog set upvote=upvote-1 where blogid='$blogid'");
			   
			   }





				setcookie('downvote_'.$blogid,"yes",time()+60*60*24*365*5);
				$sql="UPDATE blog set downvote=downvote+1 where blogid='$blogid'";
				  $operation="downvote";
			}
			
		}
		mysqli_query($con,$sql);
		//mysqli_query($con,$sql2);
		$row=mysqli_fetch_assoc(mysqli_query($con,"select * from blog where blogid='$blogid'"));
		echo json_encode([
		'operation'=>$operation,
		'upvote'=>$row['upvote'],
		'downvote'=>$row['downvote']

		]);

		
}

?>