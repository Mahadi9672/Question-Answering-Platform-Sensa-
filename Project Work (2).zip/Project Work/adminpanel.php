<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'sensa');
?>


<!DOCTYPE html>
<html>
<head>
	<title>Admin Panel</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="addcategories.css">
</head>
<body>
	<!---Navigation Part--->

	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="adminpanel.php" class="navbar-brand">Admin Panel (SenSa)</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					  <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Category</a>
						<div class="dropdown-menu dropdown-menu-dark">

              <a href="addcategories.php" class="dropdown-item">Add Category</a>
					   <a href="deletecategory.php" class="dropdown-item">Delete Category</a>
						  
						</div>
					   </li>

					   <li class="nav-item">
						<a  class="nav-link" href="manageuser.php">Manage User</a>
					</li>

					<li class="nav-item">
						<a  class="nav-link" href="contact-info.php">Contact info</a>
					</li>

					<li class="nav-item">
						  <?php
              $session_user_name = $_SESSION['uname'];
              $qry="select * from admin where uname='$session_user_name'";
              $result=mysqli_query($con,$qry);
              $row=mysqli_fetch_assoc($result);
              ?>
            <button class="btn btn-success"><?php  echo $row['uname']; ?></button>
						
					</li>



           



					<li class="nav-item">
						<a  class="nav-link" href="logout.php">Logout</a>
					</li>

					
										
				</ul>
			</div>
			
		</div>
	</nav>

	<div  class="container">
  <div class="row">
  	<div class="col-sm-6 text-center pt-5"><br>
  <img src="admin.jpg" width="600px" height="400">  <br><br>
 </div>

   <div class="col-lg-6 text-center pt-5">
    <h1 class="display-3">Welcome</h1><br>
     <h1 class="display-3">To</h1><br>
     <h1 class="display-3">Admin</h1><br>
     <h1 class="display-3">Panel</h1><br>
      </div>
     
   
    
</div>
</div>
</div>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>


</body>
</html>

