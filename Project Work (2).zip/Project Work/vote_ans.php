<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','','sensa');
?>

<?php
    $id = $_GET['id'];
    echo $id;
    $v = $_GET['v'];
    $user=$_SESSION['uname'];
    $data = "SELECT * FROM `vote_ans` WHERE quesid = '$id' AND user_id = '$user'";
    $result = mysqli_query($con, $data);
    $row = mysqli_fetch_array($result);
    $ver = mysqli_num_rows($result);

    if ($ver > 0) {
        $del = "DELETE FROM vote_ans WHERE quesid = '$id' AND user_id= '$user'";
        $del_f = mysqli_query($con, $del);
        header("location: writeans.php");
    }
        if($v != $row['vote']){
            $vote = "INSERT INTO vote_ans (`quesid`, `user_id`, `vote`, `time`) VALUES ('$id', '$user', $v, NOW())";
            $vote_f = mysqli_query($con, $vote);
            header("location: writeans.php");
        }
    
    
?>